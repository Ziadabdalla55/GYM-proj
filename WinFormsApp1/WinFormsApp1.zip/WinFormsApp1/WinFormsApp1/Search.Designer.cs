﻿namespace WinFormsApp1
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Search));
            searchphonetxt = new TextBox();
            label1 = new Label();
            label2 = new Label();
            deletbtn = new Button();
            existbtn = new Button();
            okbtn = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // searchphonetxt
            // 
            searchphonetxt.Location = new Point(144, 119);
            searchphonetxt.Name = "searchphonetxt";
            searchphonetxt.Size = new Size(201, 27);
            searchphonetxt.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Black;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 118);
            label1.Name = "label1";
            label1.Size = new Size(116, 25);
            label1.TabIndex = 1;
            label1.Text = "Enter Phone";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Black;
            label2.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(394, 25);
            label2.Name = "label2";
            label2.Size = new Size(125, 46);
            label2.TabIndex = 2;
            label2.Text = "Search";
            // 
            // deletbtn
            // 
            deletbtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            deletbtn.Location = new Point(567, 566);
            deletbtn.Name = "deletbtn";
            deletbtn.Size = new Size(156, 54);
            deletbtn.TabIndex = 3;
            deletbtn.Text = "DELET";
            deletbtn.UseVisualStyleBackColor = true;
            deletbtn.MouseDown += deletbtn_MouseDown;
            // 
            // existbtn
            // 
            existbtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            existbtn.Location = new Point(782, 566);
            existbtn.Name = "existbtn";
            existbtn.Size = new Size(156, 54);
            existbtn.TabIndex = 4;
            existbtn.Text = "EXIT";
            existbtn.UseVisualStyleBackColor = true;
            existbtn.Click += existbtn_Click;
            existbtn.MouseDown += existbtn_MouseDown;
            // 
            // okbtn
            // 
            okbtn.Location = new Point(166, 191);
            okbtn.Name = "okbtn";
            okbtn.Size = new Size(123, 29);
            okbtn.TabIndex = 5;
            okbtn.Text = "OK";
            okbtn.UseVisualStyleBackColor = true;
            okbtn.MouseDown += okbtn_MouseDown;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(363, 566);
            button1.Name = "button1";
            button1.Size = new Size(156, 54);
            button1.TabIndex = 6;
            button1.Text = "BACK";
            button1.UseVisualStyleBackColor = true;
            button1.MouseDown += button1_MouseDown;
            // 
            // Search
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(963, 647);
            Controls.Add(button1);
            Controls.Add(okbtn);
            Controls.Add(existbtn);
            Controls.Add(deletbtn);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(searchphonetxt);
            DoubleBuffered = true;
            Name = "Search";
            Text = "Search";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox searchphonetxt;
        private Label label1;
        private Label label2;
        private Button deletbtn;
        private Button existbtn;
        private Button okbtn;
        private Button button1;
    }
}